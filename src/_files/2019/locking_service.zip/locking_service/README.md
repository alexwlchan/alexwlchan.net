# locking_service

This is some code for a blog post about writing a locking service in Scala type classes.

See <https://alexwlchan.net/2019/05/creating-a-locking-service-in-a-scala-type-class/>

## Usage

To run this code, you need sbt and Scala installed, then it should be enough to run:

```console
$ sbt run
```
