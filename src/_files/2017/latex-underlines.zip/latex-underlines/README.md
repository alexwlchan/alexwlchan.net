# latex-underlines

This directory has some examples of underlining with LaTeX.

To build the examples, you need `pdflatex`, `poppler` and `optipng` installed, then build the output PNGs by running:

```console
$ ./build_example.sh
```
