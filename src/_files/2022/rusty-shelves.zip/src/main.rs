/// Code for generating graphics that look like bookshelves.
///
/// This accompanies a blog post which explains how this code works,
/// including example outputs.  See https://alexwlchan.net/2022/01/rusty-shelves/
///

use image::{RgbaImage, Rgba};
use imageproc::drawing::draw_filled_rect_mut;
use imageproc::rect::Rect;
use palette::{FromColor, Hsl, Srgb};
use palette::rgb::Rgb;
use rand::Rng;
use rand::prelude::*;
use rand_pcg::Pcg64;
use std::ops::Range;

struct RectangleOptions {
    width: Range<u32>,
    height: Range<u32>,
    total_width: u32,
}

fn generate_rectangles(options: RectangleOptions) -> Vec<Rect> {
    let mut result = Vec::new();

    let mut x_coord: u32 = 0;

    let mut rng = Pcg64::seed_from_u64(0);

    while x_coord < options.total_width {
        let width = rng.gen_range(options.width.start..options.width.end);
        let height = rng.gen_range(options.height.start..options.height.end);

        let rect = Rect::at(x_coord as i32, 0).of_size(width, height);
        result.push(rect);
        x_coord += width;
    }

    result
}

fn generate_colour_like(base: Srgb<f32>) -> Srgb<f32> {
    let hsl: Hsl = Hsl::from_color(base);
    let mut rng = rand::thread_rng();

    let min_lightness = hsl.lightness * 3.0 / 4.0;
    let max_lightness = hsl.lightness * 4.0 / 3.0;

    let new_lightness = rng.gen_range(min_lightness..max_lightness);
    let new_hsl = Hsl::new(hsl.hue, hsl.saturation, new_lightness);

    Rgb::from_color(new_hsl)
}

fn main() {
    let width = 500;
    let mut img = RgbaImage::new(width, 120);

    let rectangles = generate_rectangles(
        RectangleOptions {
            width: (4..28),
            height: (60..90),
            total_width: width,
        }
    );

    // #d01c11
    let base_colour = Rgb::new(0.81568627, 0.10980392, 0.06666667);

    for r in rectangles {
        let colour: palette::Srgb<f32> = generate_colour_like(base_colour);

        let colour: image::Rgba<u8> = Rgba::from([
            (colour.red   * 255.0) as u8,
            (colour.green * 255.0) as u8,
            (colour.blue  * 255.0) as u8,
            255
        ]);

        draw_filled_rect_mut(&mut img, r, colour);
    }

    img.save("out.png").unwrap();
}
